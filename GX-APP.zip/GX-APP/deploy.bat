@echo off
REM 社交聊天应用 - Windows 自动化部署脚本
REM 作者: MiniMax Agent
REM 日期: 2025-11-22

echo.
echo 🚀 社交聊天应用 - Windows 自动化部署
echo ========================================
echo.

REM 检查前置条件
echo [INFO] 检查部署前置条件...

REM 检查 Node.js
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js 未安装，请先安装 Node.js 18+
    pause
    exit /b 1
)

REM 检查 npm
npm --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] npm 未安装，请先安装 npm
    pause
    exit /b 1
)

echo [SUCCESS] 前置条件检查完成

REM 配置环境变量
echo.
echo [INFO] 设置环境变量...

if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env
        echo [WARNING] 已创建 .env 文件，请编辑并填入正确的配置信息
        echo [WARNING] 特别是 Supabase URL 和 API Key
    ) else (
        echo [ERROR] .env.example 文件不存在
        pause
        exit /b 1
    )
) else (
    echo [INFO] .env 文件已存在
)

REM 安装依赖
echo.
echo [INFO] 安装项目依赖...

REM 清理旧的依赖
if exist "node_modules" (
    echo [INFO] 清理旧的 node_modules...
    rmdir /s /q node_modules
)

REM 安装新依赖
npm install
if %errorlevel% neq 0 (
    echo [ERROR] 依赖安装失败
    pause
    exit /b 1
)
echo [SUCCESS] 依赖安装完成

REM 类型检查
echo.
echo [INFO] 执行 TypeScript 类型检查...
npm run type-check
if %errorlevel% neq 0 (
    echo [ERROR] 类型检查失败
    pause
    exit /b 1
)
echo [SUCCESS] 类型检查通过

REM 数据库迁移检查
echo.
echo [INFO] 检查数据库迁移状态...
echo.
echo ⚠️  重要提醒：数据库迁移需要手动在 Supabase 控制台完成
echo.
echo 请按以下步骤操作：
echo 1. 访问: https://supabase.com/dashboard
echo 2. 选择项目: saiozczbjnxqeynnrlkp
echo 3. 进入 SQL Editor
echo 4. 复制并执行 social_features_migration.sql 的全部内容
echo 5. 验证所有表创建成功
echo.
set /p db_check="是否已完成数据库迁移？(y/N): "

if /i not "%db_check%"=="y" (
    echo [WARNING] 请先完成数据库迁移后再继续部署
    pause
    exit /b 1
)

REM 构建应用
echo.
echo [INFO] 构建生产版本...

echo [INFO] 构建 Web 版本...
npx expo export --platform web
if %errorlevel% neq 0 (
    echo [ERROR] Web 构建失败
    pause
    exit /b 1
)

echo [SUCCESS] 应用构建完成

REM 部署选项
echo.
echo [SUCCESS] Web 版本已准备就绪！
echo.
echo 部署选项：
echo 1. 手动上传 web-build/ 目录到您的 Web 服务器
echo 2. 使用我们的部署工具
echo 3. 部署到 Netlify/Vercel 等静态托管服务
echo.

set /p deploy_choice="选择部署方式 (1-3) 或按 Enter 跳过: "

if "%deploy_choice%"=="1" (
    echo [INFO] 准备文件...
    if not exist "dist" mkdir dist
    xcopy /e /i web-build dist
    echo [SUCCESS] 部署文件已准备在 dist/ 目录
) else if "%deploy_choice%"=="2" (
    echo [INFO] 准备使用部署工具...
    echo 请联系技术人员获取部署工具
) else if "%deploy_choice%"=="3" (
    echo [INFO] 准备部署到静态托管服务...
    echo 请按照以下指南部署：
    echo 1. 将 web-build/ 目录内容部署到 Netlify
    echo 2. 或将 web-build/ 目录内容部署到 Vercel
)

REM 验证部署
echo.
echo [INFO] 验证部署结果...
echo.
echo 🎯 部署验证清单：
echo.
echo ✅ 应用启动正常
echo ✅ 用户注册/登录功能
echo ✅ 朋友圈发布和浏览
echo ✅ 好友搜索和添加
echo ✅ 聊天和文件分享
echo ✅ 推荐系统工作
echo ✅ 性能优化生效
echo.
echo 请访问应用并逐一验证以上功能。
echo.

echo [SUCCESS] 部署流程完成！
pause