# Supabase 数据库设置指南

## 问题诊断

您的即时通讯应用已经成功部署在：https://sl82j10kqi5g.space.minimax.io

但是经过诊断发现，数据库表还没有创建，这导致注册和登录功能无法正常工作。

## 解决方案：执行数据库迁移

### 步骤1：打开Supabase控制台

1. 访问：https://supabase.com/dashboard
2. 登录您的账户
3. 找到您的项目：`saiozczbjnxqeynnrlkp`

### 步骤2：执行SQL迁移

1. 在左侧菜单中，点击 **SQL Editor**
2. 点击 **New query** 创建新查询
3. 将以下SQL代码完整复制粘贴到编辑器中：

```sql
-- =====================================================
-- Supabase Chat App 数据库迁移脚本
-- 创建时间: 2025-11-20
-- 版本: 1.0.0
-- =====================================================

-- 1. 启用必要的扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. 创建用户资料表
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建聊天会话表
CREATE TABLE IF NOT EXISTS chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT, -- 群聊名称，单聊时为NULL
  is_group BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES profiles(id) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保群聊有名称
  CONSTRAINT chats_name_check CHECK (
    (NOT is_group AND name IS NULL) OR (is_group AND name IS NOT NULL)
  )
);

-- 4. 创建聊天成员表
CREATE TABLE IF NOT EXISTS chat_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID REFERENCES chats(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保同一用户不能重复加入同一聊天
  UNIQUE(chat_id, user_id)
);

-- 5. 创建消息表
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id UUID REFERENCES chats(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'system')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- 确保消息内容不为空
  CONSTRAINT messages_content_check CHECK (length(content) > 0)
);

-- 6. 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_chat_members_chat_id ON chat_members(chat_id);
CREATE INDEX IF NOT EXISTS idx_chat_members_user_id ON chat_members(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- 7. 创建更新时间戳触发器函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- 8. 为相关表添加更新时间戳触发器
CREATE TRIGGER update_profiles_updated_at 
  BEFORE UPDATE ON profiles 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_chats_updated_at 
  BEFORE UPDATE ON chats 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_messages_updated_at 
  BEFORE UPDATE ON messages 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 9. 启用行级安全策略 (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- 10. 创建 RLS 策略

-- profiles 表策略
CREATE POLICY "用户可以查看所有用户资料" ON profiles
  FOR SELECT USING (true);

CREATE POLICY "用户只能更新自己的资料" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "用户只能插入自己的资料" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- chats 表策略
CREATE POLICY "用户可以查看自己参与的聊天" ON chats
  FOR SELECT USING (
    id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "用户可以创建聊天" ON chats
  FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "聊天创建者可以更新聊天信息" ON chats
  FOR UPDATE USING (auth.uid() = created_by);

-- chat_members 表策略
CREATE POLICY "用户可以查看自己参与的聊天的成员" ON chat_members
  FOR SELECT USING (
    chat_id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "用户可以加入聊天" ON chat_members
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "用户可以离开聊天" ON chat_members
  FOR DELETE USING (auth.uid() = user_id);

-- messages 表策略
CREATE POLICY "用户可以查看自己参与的聊天的消息" ON messages
  FOR SELECT USING (
    chat_id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "用户可以发送消息" ON messages
  FOR INSERT WITH CHECK (
    auth.uid() = user_id AND
    chat_id IN (
      SELECT chat_id FROM chat_members WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "用户可以更新自己发送的消息" ON messages
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "用户可以删除自己发送的消息" ON messages
  FOR DELETE USING (auth.uid() = user_id);

-- 11. 启用实时订阅
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE chats;
ALTER PUBLICATION supabase_realtime ADD TABLE chat_members;

-- 迁移完成提示
DO $$
BEGIN
  RAISE NOTICE 'Supabase Chat App 数据库迁移完成！';
  RAISE NOTICE '已创建以下表：';
  RAISE NOTICE '- profiles (用户资料)';
  RAISE NOTICE '- chats (聊天会话)';
  RAISE NOTICE '- chat_members (聊天成员)';
  RAISE NOTICE '- messages (消息)';
  RAISE NOTICE '';
  RAISE NOTICE '已启用功能：';
  RAISE NOTICE '- 行级安全策略 (RLS)';
  RAISE NOTICE '- 实时订阅';
  RAISE NOTICE '- 索引优化';
  RAISE NOTICE '- 触发器和函数';
END $$;
```

4. 点击 **Run** 执行SQL

### 步骤3：检查设置

执行成功后，您应该看到类似以下的成功消息：

```
✅ 创建了 profiles 表
✅ 创建了 chats 表  
✅ 创建了 chat_members 表
✅ 创建了 messages 表
✅ 启用了行级安全策略
✅ 启用了实时订阅
```

### 步骤4：测试应用

1. 返回您的应用：https://sl82j10kqi5g.space.minimax.io
2. 点击右上角的 **系统诊断** 按钮
3. 现在应该看到 **"✅ 数据库连接正常"** 的消息
4. 尝试注册新用户，应该可以成功创建账户

## 如果仍然遇到问题

### 检查认证设置

1. 在Supabase控制台左侧菜单中，点击 **Authentication** > **Settings**
2. 在 **Email Auth** 部分：
   - 确保 **Enable email confirmations** 已禁用（或者配置了邮件服务）
   - 确保 **Enable email confirmations** 已禁用以简化注册流程

### 检查RLS策略

1. 在Supabase控制台中，点击 **Database** > **Tables**
2. 检查表是否正确创建了RLS策略

## 支持信息

- **应用URL**: https://sl82j10kqi5g.space.minimax.io
- **Supabase项目**: saiozczbjnxqeynnrlkp
- **诊断工具**: 点击应用中的"系统诊断"按钮

如果执行完这些步骤后还有问题，请截图系统诊断页面的结果，我可以进一步协助您解决问题。